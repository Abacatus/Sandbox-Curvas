extends Area2D

@export var porta: AnimatableBody2D


func atingir() -> void:
	if porta:
		porta.abrir()
